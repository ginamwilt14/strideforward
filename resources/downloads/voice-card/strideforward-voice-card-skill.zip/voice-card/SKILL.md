---
name: voice-card
description: Interviews you about how you write, then builds a one-page voice card any AI assistant can follow so drafts sound like you. Use it to make, update, or write with a voice card.
---

# Voice card

A voice card is one page that tells any AI assistant how a person or small business sounds: who they write for, the words they use and avoid, a few sentences in their voice, and what their writing never does. With it, drafts for emails, posts, web pages, and replies start out sounding like them instead of like a machine.

This skill was made by StrideForward (strideforward.world) as a free tool for small business owners, nonprofit leaders, founders, and side hustlers.

## When to use it

- The person asks for a voice card, a brand voice guide, a style guide for AI, or help making AI writing sound like them.
- The person already has a voice card in the conversation and asks for a draft: follow the card (see "Writing with the card").

## How to run the interview

Be warm, plain, and quick. The person should feel like they are talking with a friend who is good with words, not filling in a form.

1. Start with one short paragraph: what a voice card is, that the interview takes about ten minutes, that they can skip anything, and one privacy rule: please leave out customers' and family members' names and personal details, and anything private.
2. Ask the questions below **a few at a time** (one round per message), in the order given. Number them. Keep your own messages short.
3. After each round, reflect back one or two things you noticed in a single sentence, then ask the next round. Do not write the card until all four rounds are done or the person asks you to go ahead.
4. If an answer is thin, offer two or three example answers they can pick from or edit. Never invent facts about the person or their business.

### Round 1: you and your people
1. What do you do, in a sentence or two, the way you would say it to a friend?
2. Who are you writing for? Describe the people you most want to reach.
3. When someone finishes reading something you wrote, how do you want them to feel?

### Round 2: how you sound
4. Pick three words for how you want to sound, and one word for how you never want to sound.
5. What words or phrases do you use a lot? These can be your own or your field's.
6. What words, phrases, or styles do you avoid, or make you cringe when you see them?

### Round 3: your own writing
7. Paste a short piece of your own writing that you like: an email, a post, or part of a web page, about 100 to 300 words. Remove any customer or family names first.
8. Share a sentence or two you love, by you or anyone, that sounds like the voice you want.

### Round 4: your rules
9. What does your writing never do? For example: no exclamation points, no slang, no hard selling, no jargon.
10. Are there topics to keep out of your writing?
11. Any formatting habits? Short paragraphs, lists or no lists, emoji or none, how you sign off.
12. Where will you use AI drafts most: emails, social posts, your website, newsletters, replies to inquiries, or something else?

## Writing the card

Write the voice card as one page of plain text that can be copied anywhere. Use only what the person told you and what their writing sample shows. If something is missing, leave the line out rather than guessing.

Use this layout:

```
VOICE CARD: [their name or business name]

Who I am: [one or two sentences, in their words]

Who I'm writing for: [their people, in their words]

How I want readers to feel: [their answer]

How I sound: [three words], never [one word]
- [three to five short notes on tone, drawn from their answers and their sample, such as sentence length, warmth, humor, directness]

Words I use: [list]
Words I avoid: [list]

Sentences that sound like me:
1. [a new sentence in their voice, about their work]
2. [a new sentence in their voice, for their people]
3. [a new sentence in their voice, as an opening line]

My writing never:
- [their rules, one per line]

Keep out: [topics] and any customer or family personal details.

Formatting: [their habits]

How to use this card: Paste it at the start of a chat, or into your assistant's custom instructions or project instructions. Then ask for a draft, for example "Using my voice card, write a reply to this inquiry." Read every draft before it goes out, and tell the assistant what to change. Update the card when your voice or your work changes.
```

Keep the card to about one page. Write the three example sentences fresh, in their voice, about their real work as they described it. Do not copy their sample word for word, and do not add claims, numbers, results, or credentials they did not give you.

## After the card

1. Ask: "Does this sound like you? Tell me anything to change, add, or remove." Refine it until they are happy.
2. Then tell them how to keep it:
   - Save the card somewhere easy to find, like a note or a document.
   - Paste it into any AI assistant (ChatGPT, Gemini, Copilot, or Claude) at the start of a chat, or into that assistant's custom instructions or project instructions, so every draft starts from it.
   - In Claude, they can keep using this skill: ask "Write this in my voice using my voice card."
3. Offer one first draft to try it out, such as a short email or post they need this week.

## Writing with the card

When a voice card is in the conversation and the person asks for writing:

- Follow the card's tone notes, words to use and avoid, never list, keep-out topics, and formatting.
- Match the length and format of the example sentences and the sample.
- Never add facts, numbers, results, or credentials the person has not given you. Leave a short placeholder in brackets instead, like [confirm: start date].
- Never include customer or family personal details.
- After the draft, ask if anything should sound more like them, and offer to update the card with what they change.

## Privacy

- Ask people to leave out customers' and family members' names and personal details, account numbers, passwords, and anything private, both in the interview and in the card.
- If they paste something that includes another person's personal details, do not repeat those details in the card. Say in one line that you left them out.
